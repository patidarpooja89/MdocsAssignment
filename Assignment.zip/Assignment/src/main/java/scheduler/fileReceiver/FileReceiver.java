package scheduler.fileReceiver;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;

import org.springframework.stereotype.Component;

@Component("fileReceiver")
public class FileReceiver {
	int i = 0;/*Temporarily for getFileName() method*/
	public void receiveFile() throws Exception {
		System.out.println("Creating Receiver Socket channnel..");
		SocketChannel socketChannel = createServerSocketChannel();
		System.out.println("Reading file from socket channnel..");
		readFileFromSocket(socketChannel);
	}
	
	public SocketChannel createServerSocketChannel() {
		ServerSocketChannel serverSocketChannel = null;
		SocketChannel socketChannel = null;
		try {
				serverSocketChannel = ServerSocketChannel.open();
				serverSocketChannel.socket().bind(new InetSocketAddress(9999));
				socketChannel = serverSocketChannel.accept();
				System.out.println("Receiver Connection established...." + socketChannel.getRemoteAddress());
				serverSocketChannel.close();
			} catch (IOException e) {
					e.printStackTrace();
			}
		 
		return socketChannel;
	}
	
	public void readFileFromSocket(SocketChannel socketChannel) {
		RandomAccessFile aFile = null;
		try {
			    String fileName = getFileName(); /*Created temporarily to see different files in received folder*/
				aFile = new RandomAccessFile("F:\\received_files\\" + fileName , "rw"); /*Give local Path to receive files*/
				ByteBuffer buffer = ByteBuffer.allocate(1024);
				FileChannel fileChannel = aFile.getChannel();
				while (socketChannel.read(buffer) > 0) {
						buffer.flip();
						fileChannel.write(buffer);
						buffer.clear();
					}
				Thread.sleep(1000);
				fileChannel.close();
				System.out.println("End of file reached..Closing Receiver channel");
				socketChannel.close();
				socketChannel.socket().close();
				System.out.println("Received!!");
		    } catch (FileNotFoundException e) {
		    		System.out.println("Error - File not found at the specified location...");
		    } catch (IOException e) {
		    	System.out.println("Error - File not found at the specified location...");
		    } catch (Exception e) {
    		        e.printStackTrace();
            }
		 
	}

	/*temporarily added below code to identify different files*/
	private String getFileName() {
		i +=1;
		String name = "file_"+i; 
		return name;
	}
}
