package scheduler.quartz;


import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import scheduler.fileReceiver.*;
 
public class ScheduledJob extends QuartzJobBean{
 
    private FileReceiver fileReceiver; 
     
    @Override
    protected void executeInternal(JobExecutionContext arg0)
            throws JobExecutionException {
    	
			try {
				fileReceiver.receiveFile();
			} catch (Exception e) {
				e.printStackTrace();
			}
    }
 
    public void setFileReceiver(FileReceiver fileReceiver) {
        this.fileReceiver = fileReceiver;
    }
}