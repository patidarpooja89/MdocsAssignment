package scheduler.fileSender;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SocketChannel;

import org.springframework.stereotype.Component;

@Component("fileSender")
public class FileSender {
	public void sendFile() throws Exception {
		System.out.println("Creating Sender channel..");
		SocketChannel socketChannel = createChannel();
		sendFile(socketChannel);
	}
	
	public SocketChannel createChannel() {
		SocketChannel socketChannel = null;
		try {
				socketChannel = SocketChannel.open();
				SocketAddress socketAddress = new InetSocketAddress("localhost", 9999);
				socketChannel.connect(socketAddress);
				System.out.println("Connected..Now sending the file");
				 
			} catch (IOException e) {
					e.printStackTrace();
			}
		return socketChannel;
	}
		 
	public void sendFile(SocketChannel socketChannel) {
		RandomAccessFile aFile = null;
		try {
				File file = new File("F:\\temp\\Test.txt"); /*Give local path to the file you want to send*/
				aFile = new RandomAccessFile(file, "r");
				FileChannel inChannel = aFile.getChannel();
				ByteBuffer buffer = ByteBuffer.allocate(1024);
				while (inChannel.read(buffer) > 0) {
						buffer.flip();
						socketChannel.write(buffer);
						buffer.clear();
					}
				Thread.sleep(1000);
				System.out.println("End of file reached..");
				socketChannel.close();
				aFile.close();
				System.out.println("Sent!!!");
			} catch (FileNotFoundException e) {
				   System.out.println("Error - File not found at the specified location...");
			} catch (IOException e) {
				   System.out.println("Error - File not found at the specified location...");
			} catch (Exception e){
				e.printStackTrace();
			}
		 
	}
}
